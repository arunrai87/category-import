=== Plugin Name ===
Contributors: saturngod
Tags: facebook,like
Requires at least: 2.6
Tested up to: 3.2.1
Stable tag: 0.9.5

Facebook Like button in all post , page and front end. You can also setting.

== Description ==

Facebook Like button in all post , page and front end and category. You can change display at Setting > Facebook Like.

Support XFBML with application ID. 

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `facebooklike.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. WP Admin -> Settings -> Facebook Like

== Frequently Asked Questions ==
= Facebook Like is not show when I use with APP ID =
Please, check first. Are you using Facebook Share and Fan Page old code ? If you are using these two, facebook like with XFBML can't work.

= How to get support =

send my mail saturngod {at} gmail dot com

== Screenshots ==

1. Facebook Like Setting Page
2. Like Button

== Changelog ==

=0.9.5=
* show at category page by Joe Niland
* add the_exceprt filer by Redazione di Tnd
* added Send Button for XFBML

=0.9=
* add language field in setting page

=0.8.2=
* add box count

=0.8=
* add top and bottom of content

=0.7=
* add meta og data for Open Graph

= 0.6 =
* add layout
= 0.5 =
* add width and height in admin panel

= 0.4 =
* bug fix

= 0.3 =
* facebook app support

= 0.2 =
* admin panel include

= 0.1 =
* no admin panel just run all page

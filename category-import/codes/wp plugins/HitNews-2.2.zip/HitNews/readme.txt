HitNews theme by NewWpThemes, http://newwpthemes.com
Online Demo: http://newwpthemes.com/demo/HitNews/
Theme URI: http://newwpthemes.com/hitnews-free-wordpress-theme/
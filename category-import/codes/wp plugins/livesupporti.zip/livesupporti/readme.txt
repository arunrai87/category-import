=== Free Live Support Chat ===
Contributors: LiveSupporti
Tags: live chat, live support, live support chat, live chat support, livesupporti, livechat, livehelp, live help, live help widget, live support software, live chat software, chat support, chat plugin, chat button, customer chat, chat module, chat widget, chat live, plugin chat, support chat, live chat button, online chat, chat online, online customer chat, customer support, chatlive, livehelp software, live help plugin, chat, live help button, livehelp button, help desk chat, helpdesk, helpdesk chat, zendesk, olark, zopim, live customer support, plugin, contact button, widget, module chat, live support widget, live chat widget, livechat widget, sidebar, online support
Requires at least: 2.8.5
Tested up to: 3.6
Stable tag: tags/1.0

Add Free Live Support Chat on your WordPress website.

== Description ==

LiveSupporti plugin for WordPress allows you to add live support chat to your WordPress website so you can chat with your visitors. We offer **Forever Free Plan** with unlimited domains, SSL encryption and chat history.

**How to install**

1. Create your free account at <a href="http://livesupporti.com/signup" target="_blank">livesupporti.com/signup</a>
2. Log into your WordPress admin panel, go to the **Plugins** menu, click **Add New**, search for **livesupporti** plugin and install it.
3. Click on **LiveSupporti** menu on the left and enter your product key. You're done!

Watch video:

[youtube http://www.youtube.com/watch?v=H4MXtFEVXYU]


Go to <a href=\"http://livesupporti.com\" target="_blank" title=\"LiveSupporti\">livesupporti.com</a> for more information.

== Installation ==

1. Create your free account at <a href="http://livesupporti.com/signup" target="_blank">livesupporti.com/signup</a>
2. Log into your WordPress admin panel and go to the **Plugins** menu.
3. Click **Add New** and search for **livesupporti**.
4. Click **Install Now**, and then **Activate Plugin**.
5. Enter your <a href="http://livesupporti.com/pk" target="_blank" title="Get product key">product key</a> and click **Save**.

== Frequently Asked Questions ==

= Is it free? =

Yes. You can use our **Forever Free Plan**.

= Do I need a LiveSupporti account to use the plugin? =

Yes. You can create your account at <a href="http://livesupporti.com/signup" target="_blank">here</a>.

== Screenshots ==

1. Live support chat on your website.
2. Settings in WordPress.
3. Agent's panel.

== Changelog ==

= 1.0 =
* Initial release.

<table class="adminlist bottom_table" style="width: 100%;clear: both;"><tr><td align="center" valign="middle" id="twoglux_ext_td" style="position: relative;">
	<div id="twoglux_bottom_link"><a href="http://2glux.com/projects/sexy-contact-form" target="_blank">Sexy Contact Form</a> developed and designed by <a href="http://2glux.com" target="_blank">2GLux.com</a></div>
	<div style="position: absolute;right: 2px;top: 7px;">
		<a href="http://2glux.com/projects/sexy-contact-form" target="_blank" id="twoglux_ext_homepage" style="margin: 0 2px 0 0px;" class="twoglux_ext_bottom_icon" title="Go to project homepage">&nbsp;</a>
		<a href="http://2glux.com/forum/simple-contact-form/" target="_blank" id="twoglux_ext_support" class="twoglux_ext_bottom_icon" title="Here You can ask any questions related to this plugin">&nbsp;</a>
		<a href="http://2glux.com/projects/sexy-contact-form" target="_blank" id="twoglux_ext_buy" class="twoglux_ext_bottom_icon" title="Buy version without backlink and limits">&nbsp;</a>
	</div>
</td></tr></table>
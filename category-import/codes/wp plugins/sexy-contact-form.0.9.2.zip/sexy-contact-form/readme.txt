=== Sexy Contact Form ===
Contributors: 2glux
Author: 2GLux
Tags: contact, form, contact form, contact forms, Attachment, contact form plugin, contact form builder, form builder, shortcode form, contact us, easy contact, easy contact form, easy contact form solution, form solution, contact me, contacts, contacts form plugin, copy, feedback, feedback form, request, send, send copy, text, responsive, Responsive Contact Form, email, ajax, captcha, multilingual, post, Posts, widget, shortcode, sidebar, html5, html, css, css3, shortcode, network, social, society, text, javascript, jquery, plugin, plugins, page, pages, ajax, content, simple, wordpress
Requires at least: 3.6
Tested up to: 3.6
Stable tag: 0.9.2

Sexy Contact Form - The Sexiest way to get contacted!

== Description ==

[Sexy Contact Form](http://2glux.com/projects/sexy-contact-form) - The Sexiest way to get contacted! You will be surprised by count of all the possible features!

= See = 
[Live Demo](http://2glux.com/projects/sexy-contact-form/demo) 
[Template Creator Demo](http://2glux.com/projects/sexy-contact-form/demo-backend) 
[Documentation](http://2glux.com/projects/sexy-contact-form/documentation) 
[Support Forum](http://2glux.com/forum/simple-contact-form) 


### Features:
* All texts are fully customizable. You can controll them throgh administrator. No need to modify text files!
* Customizable look and feel with live preview - Create your own skin using our sexy Template Creator. [See Demo](http://2glux.com/projects/sexy-contact-form/demo-backend)
* Flexible field types: name, email, phone, address, url, number, textarea, select, multiple select, checkbox, radio
* Completely new checkbox, radio selection effect, implemented special for "SEXY" extensions!
* Load countries list (239 countries)
* Flexible and user friendly interface for inputting checkbox,radio/select options.
* Set pre-checked/selected options for checkbox,radio/select types.
* Multiple email recipients, BCC, reply to email, from email
* Automatically fill in User name and email if logged in
* Allows page redirect to URL or menu item after sending email.
* Send copy to sender
* Set all fields as required or not
* Ajax based - no page reload
* High level Spam protection
* Custom email subject
* Shake effect if field is not valid
* Drag&Drop reordering for fields, and forms in administration
* 6 beautiful skins. [See demo](http://2glux.com/projects/sexy-contact-form/demo)
* Very easy to install and configure

### PRO Features:
* Flexible File Upload: Multiple file selection, drag&drop support, costum file types support, customizable validation messages, upload max&min size, etc...
* Captcha support
* Unlimited forms
* Unlimited fields
* Multiple forms on same page

###IMPORTANT: If you think you found a bug in Sexy Contact Form or have any problem or question concerning it, do not hesitate to contact us at [info@2glux.com](mailto:info@2glux.com).


### Support:
Please `use` [Support Forum](http://2glux.com/forum/simple-contact-form) for your questions and support requests!

== Installation ==

1. Upload the entire sexy-contact-form folder to the /wp-content/plugins/ directory, or upload the .zip package through Plugins->Add New->Upload.
2. Activate the plugin through the 'Plugins' menu in WordPress.

You will find 'Sexy Contact Form' menu in your WordPress admin panel.

Use it and be happy!

== Changelog ==

= V 0.9.2 - 04/10/2013 =
* Made changes in mysql tables structure. Corrected bug with Not NULL values.

= V 0.9.1 - 01/10/2013 =
* Initial release

== Screenshots == 

1. Gray template
2. Gray template in post
3. Black template
4. Blue template
5. Red template
6. Template creator
7. Fields drag&drop
8. Form options
9. Orange template
10. Poison green template

<?php

include("core.php"); //INCLUDES IMPORTANT DATABASE SETTINGS

$comment = $_POST["comment"]; //COMMENT SUBMITTED FROM THE MAIN FILE

//INSERTS COMMENT INTO THE DATABASE
if($comment){
    $t = time();
    mysql_query("INSERT INTO $table VALUES ('', '$comment', '$t')");
}

?>
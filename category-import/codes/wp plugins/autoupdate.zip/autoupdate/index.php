<html>
<head><style>
@import url("./style.css");
#download {
	background: #32baed;
	border: 1px #12495d solid;
	color: #ffffff;
	cursor: pointer;
}
#download:active {
	background: #12495d;
}
#hide_comments {
	display: none;
}
.bold {
	font-weight: bold;
}
.db {
	color: #12495d;
}
.e {
	font-size: 18px;
}
.f {
	font-size: 14px;
}
.lb {
	color: #32baed;
}
.s {
	font-size: 16px;
}
.tl {
	font-size: 12px;
}
.tw {
	font-size: 20px;
}
.ldb {
	border-bottom: 1px #12495d solid;
	display: block;
}
.llb {
	border-bottom: 1px #32baed solid;
	display: block;
}
</style>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="./time.js">

</script></head>
<body>


<?php
function tolink($text){
        $text = html_entity_decode($text);
        $text = " ".$text;
        $text = eregi_replace('(((f|ht){1}tp://)[-a-zA-Z0-9@:%_\+.~#?&//=]+)',
                '<a href="\\1">\\1</a>', $text);
        $text = eregi_replace('(((f|ht){1}tps://)[-a-zA-Z0-9@:%_\+.~#?&//=]+)',
                '<a href="\\1">\\1</a>', $text);
        $text = eregi_replace('([[:space:]()[{}])(www.[-a-zA-Z0-9@:%_\+.~#?&//=]+)',
        '\\1<a href="http://\\2">\\2</a>', $text);
        $text = eregi_replace('([_\.0-9a-z-]+@([0-9a-z][0-9a-z-]+\.)+[a-z]{2,3})',
        '<a href="mailto:\\1">\\1</a>', $text);
        return $text;
}
?>


<textarea id="comment"></textarea>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input onClick="c()" type="button" value="POST"><br>
<span id="m"></span>
<div id="comments">
<?php

include "message.php";

?>
</div>



</body>
</html>


<?php

//CONNECTS TO DATABASE (MODIFY TO YOUR SETTINGS)
$c = mysql_connect("localhost", "root", "");
$db = mysql_select_db("liveupdate", $c);
$table = 'comments';

?>
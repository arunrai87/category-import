<?php

include("core.php"); //INCLUDES IMPORTANT DATABASE SETTINGS

$time = time(); //TIMESTAMP OF THE SERVER
$q = mysql_query("SELECT * FROM $table ORDER BY timestamp DESC");

while($r=mysql_fetch_array($q)){
    $comment = $r["comment"];
    $stamp = $r["timestamp"];
    $diff = $time-$stamp; //DIFFERENCE OF POSTED TIMESTAMP & CURRENT TIMESTAMP
    
    //DIVIDES THE DIFFERENCS TO GET THE GREATEST UNIT OF TIME
    switch($diff){
        case ($diff<60):
            $count = $diff;
            $int = "seconds";
            if($count==1){
                $int = substr($int, 0, -1);
            }
        break;
        
        case ($diff>=60&&$diff<3600):
            $count = floor($diff/60);
            $int = "minutes";
            if($count==1){
                $int = substr($int, 0, -1);
            }
        break;
        
        case ($diff>=3600&&$diff<60*60*24):
            $count = floor($diff/3600);
            $int = "hours";
            if($count==1){
                $int = substr($int, 0, -1);
            }
        break;
        
        case ($diff>=60*60*24&&$diff<60*60*24*7):
            $count = floor($diff/(60*60*24));
            $int = "days";
            if($count==1){
                $int = substr($int, 0, -1);
            }
        break;
        
        case ($diff>=60*60*24*7&&$diff<60*60*24*30):
            $count = floor($diff/(60*60*24*7));
            $int = "weeks";
            if($count==1){
                $int = substr($int, 0, -1);
            }
        break;
        
        case ($diff>=60*60*24*30&&$diff<60*60*24*365):
            $count = floor($diff/(60*60*24*30));
            $int = "months";
            if($count==1){
                $int = substr($int, 0, -1);
            }
        break;
        
        case ($diff>=60*60*24*30*365&&$diff<60*60*24*365*100):
            $count = floor($diff/(60*60*24*7*30*365));
            $int = "years";
            if($count==1){
                $int = substr($int, 0, -1);
            }
        break;
    }
    echo '<span class="comment"></span><span class="stamp" id="t'.$stamp.'"><b><img src="/download.jpg" hight="44" width="44">&nbsp;&nbsp;Solomon </b>:<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b01>'.$comment.'</b01><a> '.$count.' '.$int.'ago</a><br><br></span><br>';
}

?>
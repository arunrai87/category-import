<?php

interface I_Page_Manager
{
	
}
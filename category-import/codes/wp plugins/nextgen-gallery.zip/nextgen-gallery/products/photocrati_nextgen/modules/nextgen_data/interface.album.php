<?php

class I_Album
{

}
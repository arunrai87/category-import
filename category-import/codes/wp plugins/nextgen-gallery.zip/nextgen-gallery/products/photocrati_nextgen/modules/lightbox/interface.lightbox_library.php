<?php

interface I_Lightbox_Library extends I_DataMapper_Model
{
	
}
<?php

interface I_Image_Mapper
{
    static function get_instance($context = False);
}

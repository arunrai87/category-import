<?php

interface I_Dynamic_Thumbnails_Controller
{
}
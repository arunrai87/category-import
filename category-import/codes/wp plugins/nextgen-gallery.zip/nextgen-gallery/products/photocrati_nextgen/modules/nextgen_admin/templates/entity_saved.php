<div class='success updated'>
	<p><?php echo_h($message) ?> saved successfully</p>
</div>

<?php

interface I_Gallery_Mapper
{
    static function get_instance($context = False);
}

<a
	href='https://twitter.com/NextGENGallery'
	id="ngg_twitter_follow"
	class='twitter-follow-button'
	data-show-count='false'
	data-lang='en'>
	Follow @NextGENGallery
</a>
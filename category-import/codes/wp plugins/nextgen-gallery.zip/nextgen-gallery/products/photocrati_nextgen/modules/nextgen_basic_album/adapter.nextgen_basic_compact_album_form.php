<?php

class A_NextGen_Basic_Compact_Album_Form extends Mixin_NextGen_Basic_Album_Form
{
	function get_display_type_name()
	{
		return NEXTGEN_GALLERY_NEXTGEN_BASIC_COMPACT_ALBUM;
	}
}
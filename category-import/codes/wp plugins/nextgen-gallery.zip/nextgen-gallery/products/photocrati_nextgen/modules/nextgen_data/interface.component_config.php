<?php

interface I_Component_Config
{
    function save();
    
    function delete();
    
    function is_valid();
}
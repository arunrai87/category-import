<?php

interface I_Gallery
{   
}
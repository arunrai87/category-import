var thickboxL10n = {
    loadingAnimation: photocrati_ajax.wp_site_static_url + '/wp-includes/js/thickbox/loadingAnimation.gif',
    closeImage: photocrati_ajax.wp_site_static_url + '/wp-includes/js/thickbox/tb-close.png',
    next: 'Next &gt;',
    prev: '&lt; Prev',
    image: 'Image',
    of: 'of',
    close: 'Close',
    noiframes: 'This feature requires inline frames. You have iframes disabled or your browser does not support them.'
};

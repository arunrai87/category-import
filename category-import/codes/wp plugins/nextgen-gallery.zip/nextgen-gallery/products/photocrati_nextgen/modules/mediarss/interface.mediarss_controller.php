<?php

interface I_MediaRSS_Controller
{
	
}
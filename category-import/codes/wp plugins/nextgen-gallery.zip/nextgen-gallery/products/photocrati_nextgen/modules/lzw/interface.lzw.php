<?php

interface I_Lzw
{
	function compress($obj);
	function decompress($str);
}
<?php

interface I_Image
{
    function get_gallery();
}
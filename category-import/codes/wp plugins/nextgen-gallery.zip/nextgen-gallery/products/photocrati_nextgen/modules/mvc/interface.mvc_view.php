<?php

interface I_MVC_View
{
}
